import React, { useState } from 'react';
import { Table, Upload, Search, CheckSquare, Square, Trash2 } from 'lucide-react';

interface Contact {
  fullName: string;
  email: string;
  phone: string;
  organization?: string;
}

function formatPhoneNumber(phone: string): string {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');
  
  // If the number starts with 0, replace it with 90
  if (digits.startsWith('0')) {
    return '90' + digits.slice(1);
  }
  
  // If it doesn't start with 90, add it
  if (!digits.startsWith('90')) {
    return '90' + digits;
  }
  
  return digits;
}

function parseVcf(content: string): Contact[] {
  const contacts: Contact[] = [];
  const cards = content.split('BEGIN:VCARD');

  cards.forEach(card => {
    if (!card.trim()) return;

    const contact: Contact = {
      fullName: '',
      email: '',
      phone: '',
      organization: ''
    };

    // Parse full name
    const fnMatch = card.match(/FN:(.*)/);
    if (fnMatch) contact.fullName = fnMatch[1].trim();

    // Parse email
    const emailMatch = card.match(/EMAIL.*:(.*)/);
    if (emailMatch) contact.email = emailMatch[1].trim();

    // Parse phone and format it
    const phoneMatch = card.match(/TEL.*:(.*)/);
    if (phoneMatch) {
      const rawPhone = phoneMatch[1].trim();
      contact.phone = formatPhoneNumber(rawPhone);
    }

    // Parse organization
    const orgMatch = card.match(/ORG:(.*)/);
    if (orgMatch) contact.organization = orgMatch[1].trim();

    if (contact.fullName || contact.email || contact.phone) {
      contacts.push(contact);
    }
  });

  return contacts;
}

function App() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [error, setError] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedContacts, setSelectedContacts] = useState<Set<number>>(new Set());

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.vcf')) {
      setError('Please upload a valid VCF file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const content = e.target?.result as string;
      try {
        const parsedContacts = parseVcf(content);
        setContacts(parsedContacts);
        setSelectedContacts(new Set()); // Clear selections when new file is uploaded
        setError('');
      } catch (err) {
        setError('Error parsing VCF file');
        console.error(err);
      }
    };
    reader.readAsText(file);
  };

  const filteredContacts = contacts.filter(contact => {
    const searchLower = searchQuery.toLowerCase();
    return (
      contact.fullName.toLowerCase().includes(searchLower) ||
      contact.email.toLowerCase().includes(searchLower) ||
      contact.phone.includes(searchQuery) ||
      contact.organization?.toLowerCase().includes(searchLower)
    );
  });

  const toggleContact = (index: number) => {
    const newSelected = new Set(selectedContacts);
    if (newSelected.has(index)) {
      newSelected.delete(index);
    } else {
      newSelected.add(index);
    }
    setSelectedContacts(newSelected);
  };

  const toggleAll = () => {
    if (selectedContacts.size === filteredContacts.length) {
      setSelectedContacts(new Set());
    } else {
      setSelectedContacts(new Set(filteredContacts.map((_, index) => index)));
    }
  };

  const clearSelected = () => {
    setSelectedContacts(new Set());
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8 text-center">
          <div className="flex justify-center mb-4">
            <Table className="w-12 h-12 text-blue-600" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">VCF Contact Viewer</h1>
          <p className="text-gray-600">Upload your VCF file to view contacts in a table format</p>
        </div>

        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="flex items-center justify-center w-full">
            <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100">
              <div className="flex flex-col items-center justify-center pt-5 pb-6">
                <Upload className="w-8 h-8 mb-3 text-gray-400" />
                <p className="mb-2 text-sm text-gray-500">
                  <span className="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p className="text-xs text-gray-500">VCF files only</p>
              </div>
              <input
                type="file"
                className="hidden"
                accept=".vcf"
                onChange={handleFileUpload}
              />
            </label>
          </div>
          {error && (
            <p className="mt-2 text-red-600 text-center">{error}</p>
          )}
        </div>

        {contacts.length > 0 && (
          <>
            <div className="mb-6 relative">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search contacts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none"
                />
                <Search className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
              </div>
            </div>

            {/* Selected Contacts Table */}
            {selectedContacts.size > 0 && (
              <div className="mb-8">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">Selected Contacts</h2>
                  <button
                    onClick={clearSelected}
                    className="flex items-center px-3 py-2 text-sm text-red-600 hover:text-red-800"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Clear Selection
                  </button>
                </div>
                <div className="bg-white rounded-lg shadow-sm overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Name
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Email
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Phone
                          </th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Organization
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {Array.from(selectedContacts).map(index => {
                          const contact = contacts[index];
                          return (
                            <tr key={`selected-${index}`} className="hover:bg-gray-50">
                              <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                                {contact.fullName || '-'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {contact.email || '-'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {contact.phone || '-'}
                              </td>
                              <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                {contact.organization || '-'}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* All Contacts Table */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-10">
                        <button
                          onClick={toggleAll}
                          className="hover:text-blue-600 focus:outline-none"
                        >
                          {selectedContacts.size === filteredContacts.length ? (
                            <CheckSquare className="w-5 h-5" />
                          ) : (
                            <Square className="w-5 h-5" />
                          )}
                        </button>
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Name
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Phone
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Organization
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {filteredContacts.map((contact, index) => (
                      <tr 
                        key={index} 
                        className="hover:bg-gray-50 cursor-pointer"
                        onClick={() => toggleContact(index)}
                      >
                        <td className="px-6 py-4 whitespace-nowrap">
                          {selectedContacts.has(index) ? (
                            <CheckSquare className="w-5 h-5 text-blue-600" />
                          ) : (
                            <Square className="w-5 h-5 text-gray-400" />
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {contact.fullName || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {contact.email || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {contact.phone || '-'}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {contact.organization || '-'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default App;